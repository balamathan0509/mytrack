# MyTrack Website - AI Assistant Instructions

## Project Overview
MyTrack is a taxi booking service website for Ramanathapuram, Tamil Nadu. The website is built using HTML and CSS with a focus on mobile responsiveness and easy booking via WhatsApp/phone.

## Architecture & Structure
- Static website with HTML/CSS
- Key pages:
  - `index.html`: Landing page with hero section
  - `about.html`: Company information
  - `services.html`: Service listings
  - `contact.html`: Contact details with embedded map
- Styling: `style.css` contains all styles with mobile-first responsive design

## Key Patterns & Conventions
1. **Header Structure**:
```html
<header>
  <div class="logo">🚖 MyTrack</div>
  <nav><!-- Navigation menu --></nav>
</header>
```

2. **Meta Tags Pattern**: All pages include standard SEO meta tags:
```html
<meta name="description" content="MyTrack - Fast & Reliable Call Taxi service in Ramanathapuram...">
<meta name="keywords" content="MyTrack, Call Taxi Ramanathapuram...">
<meta name="author" content="Balamathan">
```

3. **Contact Information**:
- WhatsApp: 919361137232
- Phone: 9361137232
- Email: mytracktaxi@gmail.com

## Critical Components
1. **Floating Action Buttons**: Present on all pages for quick access to WhatsApp and phone calls
2. **Responsive Navigation**: Collapses to mobile menu at 768px breakpoint
3. **Map Integration**: Google Maps embed in contact page

## Common Tasks & Workflows
1. **Adding a New Page**:
   - Copy header/footer structure from existing pages
   - Include all required meta tags
   - Link to `style.css`
   - Add page to navigation in all HTML files
   
2. **SEO Updates**:
   - Update `sitemap_index.xml` when adding new pages
   - Ensure all pages have proper meta descriptions
   - Reference `robots.txt` for crawling rules

## Important Files
- `style.css`: Central stylesheet with mobile-first responsive design
- `sitemap_index.xml`: XML sitemap for search engines
- `robots.txt`: Search engine crawling rules

## Dependencies & Integration Points
- Google Maps Embed API (used in contact page)
- WhatsApp click-to-chat links
- No external JavaScript dependencies

When making changes, maintain mobile responsiveness and ensure all contact methods (WhatsApp, phone, email) are consistently displayed across pages.